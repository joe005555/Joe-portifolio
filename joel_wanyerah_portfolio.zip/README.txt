JOEL WANYERAH EMMANUEL — PORTFOLIO WEBSITE

Open index.html in a browser to view the portfolio.

To publish it publicly:
1. Create or sign in to a GitHub account.
2. Create a new public repository named joel-portfolio.
3. Upload index.html to the repository.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. GitHub will provide a public website URL after deployment.

Before publishing, review the dates and descriptions, and add a phone number, GitHub link, LinkedIn link, and screenshots/demo link for the project if available.
